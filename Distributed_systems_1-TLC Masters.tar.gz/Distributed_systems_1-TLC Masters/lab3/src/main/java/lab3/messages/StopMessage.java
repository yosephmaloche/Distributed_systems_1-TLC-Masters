package lab3.messages;

import java.io.Serializable;

/**
 * This empty message is used to stop an actor.
 *
 * @author Davide Pedranz <davide.pedranz@gmail.com>
 */
public class StopMessage implements Serializable {
}
